# Task68 control/probe unsigned carrier inputs

Diagnostic only. Not an SDK release, not signed and not installed. Preserve bundle build.raft.mobile, versionCode 11301900 and original signing identity; no Hands/AppGallery upload, uninstall, data clearing or sign-out.

Base input: Mobile run 38503177796, source 4fc2ea871da9c5ec101e4c8c6832ebeda412061a, original file raft-ohos-1.13.1-diag-113bb09c-11301900.app.
Base .app SHA256: 11346f726763bc23bebf3a2e4bc993bbdf6c7b051677f8a5a6b0a8ea4503422c
The original .app is not duplicated in this archive; retrieve it from its CI artifact.

Probe: KuiklyUI PR201 head a76e111b65e1e922e6340f98611672732e590dbf. HAR from Task93 CI38595671669, artifact11910785105; native compile passed. Complete CI/independent review are tracked separately. No auto-merge/release is registered.
Control: KuiklyUI PR199 head8226bb433c1fb97c0ac424979ab77add9d6258e5, CI38587540310. OHOS sources match the probe baseline; later PR200 base changes are iOS-only. Comparing the old installed renderer directly to probe also includes earlier frame-monitor changes, so use paired control/probe when diagnosing.

The helper only creates unsigned HAPs, does not sign or access credentials. With the original .app locally available, run once per variant:

```sh
python3 prepare_native_probe_hap.py --base /path/to/original.app --expected-base-sha256 11346f726763bc23bebf3a2e4bc993bbdf6c7b051677f8a5a6b0a8ea4503422c --renderer control/libkuikly.so --expected-renderer-sha256 e8067971e1a7f0dd36369a61f790e758457310e4989a89b116268dc0c19a449b --output control-UNSIGNED.hap --manifest control-manifest.json
python3 prepare_native_probe_hap.py --base /path/to/original.app --expected-base-sha256 11346f726763bc23bebf3a2e4bc993bbdf6c7b051677f8a5a6b0a8ea4503422c --renderer probe/libkuikly.so --expected-renderer-sha256 acf28fc36a11b08b545fe9299d7a3281ab8536704b90ac56237bd0e830d8359f --output probe-UNSIGNED.hap --manifest probe-manifest.json
```

Root generated both carriers and compared all 264 entry contents: only libs/arm64-v8a/libkuikly.so differs. The libshared/libentry/ArkTS entries retain original hashes. Local unsigned control HAP SHA f92dc0dc03f1280e33991c5730f04a7ce5e6fb47b91e101e5b3a521348ab8bfc; probe SHA 4d2df3e1af344d8f0b5d9bacff07d0e3295a3462acffaa6009b3b4d1cbfd483e. ZIP container compression can vary by runtime; compare per-entry content as well as record each actual HAP SHA.

Use existing managed signing identity and verify signature/profile/bundle/code signing. ZIP alignment and installability are not established by this helper. An existing authorized exact-source full rebuild is also acceptable with explicit changed-library provenance. Do not expose signer secrets. Preserve both unsigned and final signed hashes and return signing verification before in-place install. Login preservation must be checked on device, never assumed.
